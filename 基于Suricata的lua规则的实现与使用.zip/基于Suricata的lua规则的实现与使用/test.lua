function init (args)
    local needs = {}
    needs["type"] = "packet"
    return needs
end

name = "pcap-lua.log"
function setup (args)
    filename = SCLogPath() .. "/" .. name
    file = assert(io.open(filename, "a"))
    SCLogInfo("pcap Log Filename " .. filename)
    pcap = 0
end

function log(args)
    ts = SCPacketTimeString()
    ipver, srcip, dstip, proto, sp, dp = SCPacketTuple()
    p = SCPacketPayload()
file:write (" \n[**]ts: " .. ts .. 
            " \n[**]proto: " .. proto ..  
            " \n[**]srcip -> dstip: " .. srcip .. " -> " ..dstip ..
            " \n[**]sp -> dp: " .. sp .. "->" .. dp .. 
            " \n[**]type(p): " .. type(p) ..
            " \n[**]p: " .. p ..
            "\n\n\n")


    file:flush()

    pcap = pcap + 1
end

function deinit (args)
    SCLogInfo ("pcap transactions logged: " .. pcap);
    file:close(file)
end
